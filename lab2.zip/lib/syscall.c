#include "lib.h"
#include "types.h"

typedef char *  va_list;
#define _INTSIZEOF(n)   ( (sizeof(n) + sizeof(int) - 1) & ~(sizeof(int) - 1) )
#define va_start(ap, format) ( ap = (va_list)&format+ _INTSIZEOF(format) )
#define va_arg(ap, type) ( *(type*)((ap += _INTSIZEOF(type)) -_INTSIZEOF(type)) )
#define va_end(ap)  ( ap = (va_list)0 )

/*
 * io lib here
 * 库函数写在这
 */


//static inline int32_t syscall(int num, uint32_t a1,uint32_t a2,
int32_t syscall(int num, uint32_t a1,uint32_t a2,
		uint32_t a3, uint32_t a4, uint32_t a5)
{
	int32_t ret = 0;
	//Generic system call: pass system call number in AX
	//up to five parameters in DX,CX,BX,DI,SI
	//Interrupt kernel with T_SYSCALL
	//
	//The "volatile" tells the assembler not to optimize
	//this instruction away just because we don't use the
	//return value
	//
	//The last clause tells the assembler that this can potentially
	//change the condition and arbitrary memory locations.

	/*
		 Note: ebp shouldn't be flushed
	    May not be necessary to store the value of eax, ebx, ecx, edx, esi, edi
	*/
	uint32_t eax, ecx, edx, ebx, esi, edi;
	uint16_t selector;
	
	asm volatile("movl %%eax, %0":"=m"(eax));
	asm volatile("movl %%ecx, %0":"=m"(ecx));
	asm volatile("movl %%edx, %0":"=m"(edx));
	asm volatile("movl %%ebx, %0":"=m"(ebx));
	asm volatile("movl %%esi,  %0":"=m"(esi));
	asm volatile("movl %%edi,  %0":"=m"(edi));
	asm volatile("movl %0, %%eax": :"m"(num));
	asm volatile("movl %0, %%ecx"::"m"(a1));
	asm volatile("movl %0, %%edx"::"m"(a2));
	asm volatile("movl %0, %%ebx"::"m"(a3));
	asm volatile("movl %0, %%esi" ::"m"(a4));
	asm volatile("movl %0, %%edi" ::"m"(a5));
	asm volatile("int $0x80");
	asm volatile("movl %%eax, %0":"=m"(ret));
	asm volatile("movl %0, %%eax"::"m"(eax));
	asm volatile("movl %0, %%ecx"::"m"(ecx));
	asm volatile("movl %0, %%edx"::"m"(edx));
	asm volatile("movl %0, %%ebx"::"m"(ebx));
	asm volatile("movl %0, %%esi"::"m"(esi));
	asm volatile("movl %0, %%edi"::"m"(edi));
	
	asm volatile("movw %%ss, %0":"=m"(selector)); //%ds is reset after iret
	//selector = 16;
	asm volatile("movw %%ax, %%ds"::"a"(selector));
	
	return ret;
}


//TODO This is a lib function
char getChar()
{ // 对应SYS_READ STD_IN
	// TODO: 实现getChar函数，方式不限
	char ch = 0; 

	while (ch == 0)
	{
		ch = syscall(SYS_READ, STD_IN, 0, 0, 0, 0);
	}

	ch = (char)ch;

	return ch;	
}


//TODO This is a lib function
void getStr(char *str, int size)
{ // 对应SYS_READ STD_STR
	// TODO: 实现getStr函数，方式不限
	int ch = 0;

	while (ch == 0)
	{
		ch = syscall(SYS_READ, STD_STR, (uint32_t)str, size, 0, 0);
	}

	return;
}

int dec2Str(int decimal, char *buffer, int size, int count);
int hex2Str(uint32_t hexadecimal, char *buffer, int size, int count);
int str2Str(char *string, char *buffer, int size, int count);

//This is a lib function

// 辅助函数：写满自动 flush
static inline void flushBufferIfFull(char *buffer, int *count)
{
	if (*count >= MAX_BUFFER_SIZE)
	{
		syscall(SYS_WRITE, STD_OUT, (uint32_t)buffer, *count, 0, 0);
		*count = 0;
	}
}

// 写入整数（支持十进制、十六进制、无符号）
static int writeInt(uint32_t value, int base, int isSigned, char *buffer, int count)
{
	if (isSigned)
	{
		int val = (int)value;
		return dec2Str(val, buffer, MAX_BUFFER_SIZE, count);
	} else {
		if (base == 10)
			return dec2Str(value, buffer, MAX_BUFFER_SIZE, count);
		else
			return hex2Str(value, buffer, MAX_BUFFER_SIZE, count);
	}
}

// 写入指针（统一以 0x 开头十六进制）
static int writePointer(void *ptr, char *buffer, int count)
{
	count = str2Str("0x", buffer, MAX_BUFFER_SIZE, count);
	return hex2Str((uint32_t)ptr, buffer, MAX_BUFFER_SIZE, count);
}



void printf(const char *format,...)
{
	int i=0; // format index
	char buffer[MAX_BUFFER_SIZE];
	int count=0; // buffer index
	//int index=0; // parameter index
	int shift = sizeof(uint32_t);
	void *paraList=(void*)&format;
	paraList += shift; 
	int state=0; // 0: legal character; 1: '%'; 2: illegal format
	int decimal=0;
	uint32_t hexadecimal=0;
	char *string=0;
	char character=0;

	(void)character;
	(void)decimal;
	(void)hexadecimal;
	(void)string;


	while (format[i] != 0) 
	{
		char ch = format[i++];
		
		
		if (state == 0) 
		{
			if (ch == '%') 
			{
				state = 1;
			} 
			else 
			{
				buffer[count++] = ch;
			}
		} 
		else if (state == 1) 
		{
			state = 0;
	
			// 判断ch的值
			if (ch == 'd') 
			{
				count = writeInt(*(int*)paraList, 10, 1, buffer, count);
				paraList += 4;
			} 
			else if (ch == 'u') 
			{
				count = writeInt(*(uint32_t*)paraList, 10, 0, buffer, count);
				paraList += 4;
			} 
			else if (ch == 'x') 
			{
				count = writeInt(*(uint32_t*)paraList, 16, 0, buffer, count);
				paraList += 4;
			} 
			else if (ch == 'p') 
			{
				count = writePointer(*(void**)paraList, buffer, count);
				paraList += 4;
			} 
			else if (ch == 's') 
			{
				char *str = *(char**)paraList;
				paraList += 4;
				count = str2Str(str, buffer, MAX_BUFFER_SIZE, count);
			} 
			else if (ch == 'c') 
			{
				char c = *(char*)paraList;
				paraList += 4;
				buffer[count++] = c;
			} 
			else 
			{
				state = 2; // 错误格式
			}
	
			flushBufferIfFull(buffer, &count);
		} 
		else if (state == 2) 
		{
			return;
		} 
		else 
		{
			// 不需要额外处理其他case
		}
	}
	
	
	if(count!=0)
		syscall(SYS_WRITE, STD_OUT, (uint32_t)buffer, (uint32_t)count, 0, 0);
}


//TODO: 这个函数是用来让当前进程睡眠一段时间

//封装两个系统调用
// 1. 获取时间标志
// 2. 设置时间标志
// 这两个系统调用的实现可以在 kernel/kernel/irqHandle.c 中找到

static int getTimeFlag()
{
	return syscall(SYS_GET_TIME_FLAG, 0, 0, 0, 0, 0);
}

static int setTimeFlag()
{
	return syscall(SYS_SET_TIME_FLAG, 0, 0, 0, 0, 0);
}

void sleep(unsigned int seconds)
{

	// 调用 sysSetTimeFlag() 使 timeFlag 为 0
	setTimeFlag();

	// 等待 timeFlag 被设置为 1
	for (unsigned int i = 0; i < seconds * 100; i++)
	{  // 1秒大约需要100次循环，每次10ms

		while (getTimeFlag() == 0);  // 等待 timeFlag 为 1
		
		
		setTimeFlag();  // 重置 timeFlag
	}
}


//TODO: 这个函数是用来获取当前时间的

static inline unsigned char readCMOS(unsigned char reg) 
{
    // 将寄存器号写入 0x70 端口
	//printf("readCMOS reg = %d\n", reg);
	syscall(SYS_OUT, 0x70, reg, 0, 0, 0);
	// 从 0x71 端口读取数据
	unsigned char data = syscall(SYS_IN, 0x71, 0, 0, 0, 0);
    return data;
}

// 将 BCD 编码转换为十进制数字
static inline int bcdToDec(unsigned char bcd)
{
    return ((bcd >> 4) * 10) + (bcd & 0x0F);
}

void now(struct TimeInfo* tm_info)
{

	//printf("now() called\n");
    tm_info->second = bcdToDec(readCMOS(0x00)); // 秒寄存器
    tm_info->minute = bcdToDec(readCMOS(0x02)); // 分寄存器
    tm_info->hour   = bcdToDec(readCMOS(0x04)); // 时寄存器
    tm_info->m_day  = bcdToDec(readCMOS(0x07)); // 日寄存器
    tm_info->month  = bcdToDec(readCMOS(0x08)); // 月寄存器
    tm_info->year   = bcdToDec(readCMOS(0x09)); // 年寄存器

	// 获取 registerB 的值，用于判断是否为 12 小时制
	uint8_t registerB = readCMOS(0x0B);  // CMOS 的 B 寄存器

	// 如果是 12 小时制，且 PM 标志位为 1，则进行转换
	if (!(registerB & 0x02) && (tm_info->hour & 0x80)) 
	{
	// 12 小时制转换为 24 小时制
	tm_info->hour = ((tm_info->hour & 0x7F) + 12) % 24;
	}
}


int dec2Str(int decimal, char *buffer, int size, int count)
{
	int i=0;
	int temp;
	int number[16];

	if(decimal<0){
		buffer[count]='-';
		count++;
		if(count==size) {
			syscall(SYS_WRITE, STD_OUT, (uint32_t)buffer, (uint32_t)size, 0, 0);
			count=0;
		}
		temp=decimal/10;
		number[i]=temp*10-decimal;
		decimal=temp;
		i++;
		while(decimal!=0){
			temp=decimal/10;
			number[i]=temp*10-decimal;
			decimal=temp;
			i++;
		}
	}
	else{
		temp=decimal/10;
		number[i]=decimal-temp*10;
		decimal=temp;
		i++;
		while(decimal!=0){
			temp=decimal/10;
			number[i]=decimal-temp*10;
			decimal=temp;
			i++;
		}
	}

	while(i!=0){
		buffer[count]=number[i-1]+'0';
		count++;
		if(count==size) {
			syscall(SYS_WRITE, STD_OUT, (uint32_t)buffer, (uint32_t)size, 0, 0);
			count=0;
		}
		i--;
	}
	return count;
}

int hex2Str(uint32_t hexadecimal, char *buffer, int size, int count) {
	int i=0;
	uint32_t temp=0;
	int number[16];

	temp=hexadecimal>>4;
	number[i]=hexadecimal-(temp<<4);
	hexadecimal=temp;
	i++;
	while(hexadecimal!=0){
		temp=hexadecimal>>4;
		number[i]=hexadecimal-(temp<<4);
		hexadecimal=temp;
		i++;
	}

	while(i!=0){
		if(number[i-1]<10)
			buffer[count]=number[i-1]+'0';
		else
			buffer[count]=number[i-1]-10+'a';
		count++;
		if(count==size) {
			syscall(SYS_WRITE, STD_OUT, (uint32_t)buffer, (uint32_t)size, 0, 0);
			count=0;
		}
		i--;
	}
	return count;
}

int str2Str(char *string, char *buffer, int size, int count) {
	int i=0;
	while(string[i]!=0){
		buffer[count]=string[i];
		count++;
		if(count==size) {
			syscall(SYS_WRITE, STD_OUT, (uint32_t)buffer, (uint32_t)size, 0, 0);
			count=0;
		}
		i++;
	}
	return count;
}

