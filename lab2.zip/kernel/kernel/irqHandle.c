#include "x86.h"
#include "device.h"

extern int displayRow;
extern int displayCol;

extern uint32_t keyBuffer[MAX_KEYBUFFER_SIZE];
extern int bufferHead;
extern int bufferTail;

extern int timeFlag; //defined in timer.c

int tail=0;

void GProtectFaultHandle(struct TrapFrame *tf);

void KeyboardHandle(struct TrapFrame *tf);

void timerHandler(struct TrapFrame *tf);
void syscallHandle(struct TrapFrame *tf);
void sysWrite(struct TrapFrame *tf);
void sysPrint(struct TrapFrame *tf);
void sysRead(struct TrapFrame *tf);
void sysGetChar(struct TrapFrame *tf);
void sysGetStr(struct TrapFrame *tf);
void sysSetTimeFlag(struct TrapFrame *tf);
void sysGetTimeFlag(struct TrapFrame *tf);

static inline void advanceCursor() 
{
	if (displayCol == 80) 
	{
		displayRow++;
		displayCol = 0;
	}
}

static inline void adjustScreen() 
{
	if (displayRow >= 25) 
	{
		do {
			scrollScreen();
			displayRow--;
			displayCol = 0;
		} while (displayRow >= 25);
	}
}

static inline void writeCharToScreen(char character) 
{
	uint16_t data = 0x0c00 | character;  

	int pos = displayRow * 80 + displayCol;

	pos = pos << 1; 

	asm volatile("movw %0, (%1)"::"r"(data), "r"(pos + 0xb8000));

	displayCol++;
}


void irqHandle(struct TrapFrame *tf) { // pointer tf = esp
	/*
	 * 中断处理程序
	 */
	/* Reassign segment register */
	asm volatile("movw %%ax, %%ds"::"a"(KSEL(SEG_KDATA)));

	switch(tf->irq) {
		// TODO: 填好中断处理程序的调用
		case 0xd:
			GProtectFaultHandle(tf);
			break;
		case 0x20: //process timer interrupt
			timerHandler(tf);
			break;	
		case 0x21:
			KeyboardHandle(tf);
			break;
		case 0x80:
			syscallHandle(tf);
			break;
		default:break;
	}
}

void GProtectFaultHandle(struct TrapFrame *tf)
{
	assert(0);
	return;
}


void timerHandler(struct TrapFrame *tf)
{
	// 每次定时器中断触发时，设置 timeFlag为 1，表示时钟中断已发生
	timeFlag = 1;  

	outByte(0x20, 0x20);  // PIC1，向 PIC 发送 EOI 信号（结束中断）

}

void KeyboardHandle(struct TrapFrame *tf)
{
	uint32_t code = getKeyCode();

	if(code == 0xe)
	{ // 退格符
		//要求只能退格用户键盘输入的字符串，且最多退到当行行首
		if(displayCol>0&&displayCol>tail){
			displayCol--;
			uint16_t data = 0 | (0x0c << 8);
			int pos = (80*displayRow+displayCol)*2;
			asm volatile("movw %0, (%1)"::"r"(data),"r"(pos+0xb8000));
		}
	}
	else if(code == 0x1c)
	{ // 回车符
		//处理回车情况
		keyBuffer[bufferTail++]='\n';
		displayRow++;
		displayCol=0;
		tail=0;
		if(displayRow==25){
			scrollScreen();
			displayRow=24;
			displayCol=0;
		}
	}
	else if(code < 0x81)
	{ 
		// TODO: 处理正常的字符
		char ch = getChar(code);
		if (ch >= 0x20)
		{
			putChar(ch);

			keyBuffer[bufferTail++] = ch;
		
			// 设置用户数据段选择子到 ES
			unsigned short userDataSeg = USEL(SEG_UDATA);
			asm volatile("movw %0, %%es"::"m"(userDataSeg));
			
			writeCharToScreen(ch);
			advanceCursor();
			adjustScreen();

		}
	}
	updateCursor(displayRow, displayCol);
	
}


//I/O defined in io.h
//I add SYS_IN and SYS_OUT for now() lib func
void syscallHandle(struct TrapFrame *tf) 
{
	switch(tf->eax) 
	{
		case 0:
			sysWrite(tf);
			break;
		case 1:
			sysRead(tf);
			break;

		case 2:
		{ // SYS_IN
			uint16_t port = (uint16_t)tf->ecx;
			uint8_t value = inByte(port);
			tf->eax = (uint32_t)value; // 返回结果到 eax
			break;
		}

		case 3:
		{ // SYS_OUT
			uint16_t port = (uint16_t)tf->ecx;
			uint8_t data  = (uint8_t)tf->edx;
			outByte(port, data);
			tf->eax = 0; // 成功返回 0
			break;
		}

		case 4: 
			sysSetTimeFlag(tf); 
			break;
		case 5: 
			sysGetTimeFlag(tf); 
			break;

		default:
			break;
	}
}


void sysWrite(struct TrapFrame *tf) 
{
	switch(tf->ecx) 
	{ // file descriptor
		case 0:
			sysPrint(tf);
			break; // for STD_OUT
		default:break;
	}
}

void sysPrint(struct TrapFrame *tf)
{
	int sel =  USEL(SEG_UDATA);
	char *str = (char*)tf->edx;
	int size = tf->ebx;
	int i = 0;
	int pos = 0;
	char ch = 0;
	uint16_t data = 0;

	(void)data;
	(void)pos;
	//just for cheating compiler

	asm volatile("movw %0, %%es"::"m"(sel));
	for (i = 0; i < size; i++) 
	{
		asm volatile("movb %%es:(%1), %0":"=r"(ch):"r"(str+i));
		// TODO: 完成光标的维护和打印到显存
		if (ch != '\n') //非换行符号
		{
			writeCharToScreen(ch);

		} 
		else 
		{
			displayRow++;
			displayCol = 0;
		}
	
		
		advanceCursor();
		adjustScreen();
	
	}
	tail=displayCol;
	updateCursor(displayRow, displayCol);
}

void sysRead(struct TrapFrame *tf)
{
	switch(tf->ecx){ //file descriptor
		case 0:
			sysGetChar(tf);
			break; // for STD_IN
		case 1:
			sysGetStr(tf);
			break; // for STD_STR
		default:break;
	}
}

#define GET_FAILED do { tf->eax = 0; return; } while (0)


void sysGetChar(struct TrapFrame *tf)
{
	// 如果缓冲区为空或者不以 '\n' 结尾，直接返回 0
	if (bufferTail <= bufferHead || keyBuffer[bufferTail - 1] != '\n')
	{
		GET_FAILED;
	}

	// 去除尾部的换行符
	while (bufferTail > bufferHead && keyBuffer[bufferTail - 1] == '\n') 
	{
		keyBuffer[--bufferTail] = '\0';
	}

	// 返回最后一个字符，然后清空缓冲区
	tf->eax = keyBuffer[--bufferTail];
	bufferHead = bufferTail;
}

void sysGetStr(struct TrapFrame *tf)
{
	// TODO: 自由实现
	int maxSize = tf->ebx;

	char *userStr = (char*)tf->edx;

	// 设置 ES 段寄存器为用户数据段
	unsigned short userDataSeg = USEL(SEG_UDATA);
	asm volatile("movw %0, %%es"::"m"(userDataSeg));

	// 检查缓冲区末尾是否有换行
	int hasNewline = (keyBuffer[bufferTail - 1] == '\n');

	// 去除尾部多余的 '\n'
	while (bufferTail > bufferHead && keyBuffer[bufferTail - 1] == '\n')
	{
		keyBuffer[--bufferTail] = '\0';
	}

	// 条件不满足：没有换行，且数据不够
	if (!hasNewline && (bufferTail - bufferHead < maxSize)) 
	{
		GET_FAILED;
	}

	// 拷贝数据到用户空间
	int available = bufferTail - bufferHead;
	int count = (maxSize < available) ? maxSize : available;

	for (int i = 0; i < count; i++)
	{
		char ch = keyBuffer[bufferHead + i];
		asm volatile("movb %0, %%es:(%1)"::"r"(ch), "r"(userStr + i));
	}

	tf->eax = 1;
}


void sysSetTimeFlag(struct TrapFrame *tf)
{
	timeFlag = 0;
	tf->eax = 0;	
}
void sysGetTimeFlag(struct TrapFrame *tf)
{
	tf->eax = timeFlag;
}