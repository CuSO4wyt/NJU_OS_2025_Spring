#include "x86.h"
#include "device.h"

SegDesc gdt[NR_SEGMENTS];       // the new GDT, NR_SEGMENTS=7, defined in x86/memory.h
TSS tss;

//init GDT and LDT
void initSeg() { // setup kernel segements
	gdt[SEG_KCODE] = SEG(STA_X | STA_R, 0,       0xffffffff, DPL_KERN);
	gdt[SEG_KDATA] = SEG(STA_W,         0,       0xffffffff, DPL_KERN);
	//gdt[SEG_UCODE] = SEG(STA_X | STA_R, 0,       0xffffffff, DPL_USER);
	gdt[SEG_UCODE] = SEG(STA_X | STA_R, 0x00200000,0x000fffff, DPL_USER);
	//gdt[SEG_UDATA] = SEG(STA_W,         0,       0xffffffff, DPL_USER);
	gdt[SEG_UDATA] = SEG(STA_W,         0x00200000,0x000fffff, DPL_USER);
	gdt[SEG_TSS] = SEG16(STS_T32A,      &tss, sizeof(TSS)-1, DPL_KERN);
	gdt[SEG_TSS].s = 0;
	setGdt(gdt, sizeof(gdt)); // gdt is set in bootloader, here reset gdt in kernel

	/*
	 * 初始化TSS
	 */
	tss.esp0 = 0x1fffff;
	tss.ss0 = KSEL(SEG_KDATA);
	asm volatile("ltr %%ax":: "a" (KSEL(SEG_TSS)));

	/*设置正确的段寄存器*/
	asm volatile("movw %%ax,%%ds":: "a" (KSEL(SEG_KDATA)));
	//asm volatile("movw %%ax,%%es":: "a" (KSEL(SEG_KDATA)));
	//asm volatile("movw %%ax,%%fs":: "a" (KSEL(SEG_KDATA)));
	//asm volatile("movw %%ax,%%gs":: "a" (KSEL(SEG_KDATA)));
	asm volatile("movw %%ax,%%ss":: "a" (KSEL(SEG_KDATA)));

	lLdt(0);
	
}

void enterUserSpace(uint32_t entry) {
	/*
	 * Before enter user space 
	 * you should set the right segment registers here
	 * and use 'iret' to jump to ring3
	 */
	uint32_t EFLAGS = 0;
	asm volatile("pushl %0":: "r" (USEL(SEG_UDATA))); // push ss
	asm volatile("pushl %0":: "r" (0x2fffff)); 
	asm volatile("pushfl"); //push eflags, sti
	asm volatile("popl %0":"=r" (EFLAGS));
	asm volatile("pushl %0"::"r"(EFLAGS|0x200));
	asm volatile("pushl %0":: "r" (USEL(SEG_UCODE))); // push cs
	asm volatile("pushl %0":: "r" (entry)); 
	asm volatile("iret");
}

/*
kernel is loaded to location 0x100000, i.e., 1MB
size of kernel is not greater than 200*512 bytes, i.e., 100KB
user program is loaded to location 0x200000, i.e., 2MB
size of user program is not greater than 200*512 bytes, i.e., 100KB
*/

void loadUMain(void)
{
	// TODO: 参照bootloader加载内核的方式，由kernel加载用户程序

	int i = 0;
    uint32_t uMain = 0x200000; // 用户程序加载地址，从注释可知
    uint32_t uMainEntry = 0;   // 用户程序入口点，后面会从ELF头中读取
    
    // 读取磁盘扇区，将用户程序加载到内存
    for (i = 0; i < 200; i++)
	{
        readSect((void*)(uMain + i*512), 201+i); // 从第201个扇区开始读取用户程序
    }
    
    // 解析ELF头信息
    ELFHeader *elfHeader = (ELFHeader *)uMain;
    
    // 检查ELF魔数
    if (elfHeader->magic != 0x464C457F)
	{ // 0x7F 'E' 'L' 'F'
        // ELF格式错误
        assert(0);
    }
    
    // 获取程序头表偏移
    uint32_t phoff = elfHeader->phoff;
    ProgramHeader *programHeader = (ProgramHeader *)(uMain + phoff);
    
    // 获取程序段偏移
    uint32_t offset = programHeader->off;
    
    // 获取入口点
    uMainEntry = elfHeader->entry;
    
    // 将程序从ELF文件中的偏移位置复制到加载地址
    for (i = 0; i < 200 * 512; i++)
	{
        if (i + offset < 200 * 512)
		{ // 边界检查
            *(unsigned char *)(uMain + i) = *(unsigned char *)(uMain + i + offset);
        }
    }
    
	enterUserSpace(uMainEntry);
	
}
