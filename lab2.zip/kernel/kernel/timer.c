#include "x86.h"
#include "device.h"

#define TIMER_PORT 0x40
#define FREQ_8253 1193182
#define HZ 100
//#define HZ 1000

int timeFlag = 0; // 定义一个全局变量，用于标记时间是否到达

// 初始化定时器
void initTimer()
{
    int counter = FREQ_8253 / HZ;  // 计算定时器计数器的值，HZ为中断频率（100Hz）

    // 设置计数器模式
    outByte(TIMER_PORT + 3, 0x34);  // 选择定时器工作模式（0x34是可编程定时器模式）

    // 将计数器值传送到定时器端口
    outByte(TIMER_PORT + 0, counter % 256);   // 低字节
    outByte(TIMER_PORT + 0, counter / 256);   // 高字节
}
