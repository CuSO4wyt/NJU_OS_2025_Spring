#include "x86.h"
#include "device.h"

#define SYS_WRITE 0
#define SYS_FORK 1
#define SYS_EXEC 2
#define SYS_SLEEP 3
#define SYS_EXIT 4
#define SYS_GETPID 5

extern TSS tss;
extern ProcessTable pcb[MAX_PCB_NUM];
extern int current;

extern int displayRow;
extern int displayCol;

void GProtectFaultHandle(struct StackFrame *sf);

void timerHandle(struct StackFrame *sf);

void syscallHandle(struct StackFrame *sf);

void sysWrite(struct StackFrame *sf);
void sysPrint(struct StackFrame *sf);

void sysFork(struct StackFrame *sf);
void sysExec(struct StackFrame *sf);
void sysSleep(struct StackFrame *sf);
void sysExit(struct StackFrame *sf);
void sysGetPid(struct StackFrame *sf);

uint32_t schedule();
void contextSwitch(int prev, int new);
uint32_t loadUMain(uint32_t first_sector, uint32_t sector_count, uint32_t pid);

/*
kernel is loaded to location 0x100000, i.e., 1MB
size of kernel is not greater than 200*512 bytes, i.e., 100KB
user program is loaded to location 0x200000, i.e., 2MB
size of user program is not greater than 200*512 bytes, i.e., 100KB
*/
uint32_t loadUMain(uint32_t first_sector, uint32_t sector_count, uint32_t pid)
{
	int i = 0;
	// int phoff = 0x34;					 // program header offset
	int offset = 0x1000;				 // .text section offset
	uint32_t elf = 0x100000 * (pid + 1); // physical memory addr to load
	uint32_t uMainEntry = 0x100000 * (pid + 1);

	for (i = 0; i < sector_count; i++)
	{
		readSect((void *)(elf + i * 512), first_sector + i);
	}

	uMainEntry = ((struct ELFHeader *)elf)->entry; // entry address of the program
	// phoff = ((struct ELFHeader *)elf)->phoff;
	// offset = ((struct ProgramHeader *)(elf + phoff))->off;

	for (i = 0; i < sector_count * 512; i++)
	{
		*(uint8_t *)(elf + i) = *(uint8_t *)(elf + i + offset);
	}

	return uMainEntry;
}

/*
 * Schedules the next process to run
 *
 * Returns:
 *   pid_t - The process ID of the scheduled process
 *           Returns -1 if no process is available for scheduling
 */

 // Debug message macros for easier debugging


uint32_t schedule()
{
    // Save the previous process id
    int prev = current;
    int i;
    
    // Start looking from the next process
    i = (current + 1) % MAX_PCB_NUM;
    

    
    // Look for a RUNNABLE process
    while (i != current) {
        if (i != 0 && pcb[i].state == STATE_RUNNABLE) {

            break;
        }
        i = (i + 1) % MAX_PCB_NUM;
    }
    
    // If no RUNNABLE process found, select the idle process (pid = 0)
    if (i == current || pcb[i].state != STATE_RUNNABLE) {
        i = 0;
    }
    
    // No need to switch if the selected process is the same as current
    if (i == current) {
        
        return i;
    }
    
    // Update the state of the previous process if it's still RUNNING
    if (pcb[prev].state == STATE_RUNNING) {
        pcb[prev].state = STATE_RUNNABLE;
        // Debug: Process state changed
    }
    
    // Update current to the selected process
    current = i;
    
    // Update the state and time count of the selected process
    pcb[current].state = STATE_RUNNING;
    pcb[current].timeCount = 0; // Reset time count for the new process
    
    // Perform context switch
    contextSwitch(prev, current);
    
    // Return the pid of the scheduled process
    return current;
}

void contextSwitch(int prev, int new)
{



	ProcessTable *cur_pt = pcb + new;
	cur_pt->state = STATE_RUNNING;
	current = new;
	uint32_t tmp = pcb[current].stackTop;
	pcb[current].stackTop = pcb[current].prevStackTop;
	//refer
	tss.esp0 = pcb[current].stackTop;

	asm volatile("movl %0, %%esp" ::"m"(tmp));
	asm volatile("popl %%gs\n\t"	  // 恢复 GS
				 "popl %%fs\n\t"	  // 恢复 FS
				 "popl %%es\n\t"	  // 恢复 ES
				 "popl %%ds\n\t"	  // 恢复 DS
				 "popal\n\t"		  // 恢复通用寄存器（EAX, EBX...）
				 "addl $4, %%esp\n\t" // intr
				 "addl $4, %%esp\n\t" // error node
				 "iret"				  // 中断返回
				 ::
					 : "memory", "cc");
}

void irqHandle(struct StackFrame *sf)
{
	// pointer sf = esp
	/* Reassign segment register */
	asm volatile("movw %%ax, %%ds" ::"a"(KSEL(SEG_KDATA)));
	/*XXX Save esp to stackTop */
	uint32_t tmpStackTop = pcb[current].stackTop;
	pcb[current].prevStackTop = pcb[current].stackTop;
	pcb[current].stackTop = (uint32_t)sf;

	switch (sf->irq) {
	case -1:
		break;
	case 0xd:
		GProtectFaultHandle(sf);
		break;
	case 0x20:
		timerHandle(sf);
		break;
	case 0x80:
		syscallHandle(sf);
		break;
	default:
		assert(0);
	}
	/*XXX Recover stackTop */
	pcb[current].stackTop = tmpStackTop;
}

void GProtectFaultHandle(struct StackFrame *sf)
{
	assert(0);
	return;
}

void timerHandle(struct StackFrame *sf)
{
    int i;
    int needSchedule = 0;
    
    // 1. 更新睡眠进程计时器
    for (i = 0; i < MAX_PCB_NUM; i++) {
        if (pcb[i].state == STATE_BLOCKED) {
            pcb[i].sleepTime--;
            if (pcb[i].sleepTime <= 0) {
                pcb[i].state = STATE_RUNNABLE;
                needSchedule = 1;  // 标记需要调度
                
            }
        }
    }
    
    // 2. 更新当前进程时间片
    if (pcb[current].state == STATE_RUNNING) {
        pcb[current].timeCount++;
        
        if (pcb[current].timeCount >= MAX_TIME_COUNT) {
            pcb[current].timeCount = 0;
            pcb[current].state = STATE_RUNNABLE;
            needSchedule = 1;  // 标记需要调度

        }
    }
    
    // 3. 如果当前进程已经不是RUNNING状态或者有进程被唤醒，则调度
    if (needSchedule || pcb[current].state != STATE_RUNNING) {
        schedule();
    }
}

void syscallHandle(struct StackFrame *sf)
{
	
	switch (sf->eax)
	{ // syscall number
	case 0: // for SYS_WRITE
		sysWrite(sf);
		break; // for SYS_WRITE

	case 1: //for SYS_FORK
		sysFork(sf);
		break;
	case 2: //for SYS_EXEC
		sysExec(sf);
		break;
	case 3: //for SYS_SLEEP
		sysSleep(sf);
		break;
	case 4: //for SYS_EXIT
		sysExit(sf);
		break;
	case 5: //for SYS_GETPID
		sysGetPid(sf);
		break;

	/*TODO Add Fork, Sleep, Exit, Exec... */
	default:
		break;
	}
}

void sysWrite(struct StackFrame *sf)
{
	switch (sf->ecx)
	{ // file descriptor
	case 0:
		sysPrint(sf);
		break; // for STD_OUT
	default:
		break;
	}
}

void sysPrint(struct StackFrame *sf)
{
	int sel = sf->ds; // segment selector for user data, need further modification
	char *str = (char *)sf->edx;
	int size = sf->ebx;
	int i = 0;
	int pos = 0;
	char character = 0;
	uint16_t data = 0;
	asm volatile("movw %0, %%es" ::"m"(sel));
	for (i = 0; i < size; i++)
	{
		asm volatile("movb %%es:(%1), %0" : "=r"(character) : "r"(str + i));
		if (character == '\n')
		{
			displayRow++;
			displayCol = 0;
			if (displayRow == 25)
			{
				displayRow = 24;
				displayCol = 0;
				scrollScreen();
			}
		}
		else
		{
			data = character | (0x0c << 8);
			pos = (80 * displayRow + displayCol) * 2;
			asm volatile("movw %0, (%1)" ::"r"(data), "r"(pos + 0xb8000));
			displayCol++;
			if (displayCol == 80)
			{
				displayRow++;
				displayCol = 0;
				if (displayRow == 25)
				{
					displayRow = 24;
					displayCol = 0;
					scrollScreen();
				}
			}
		}
		// asm volatile("int $0x20"); //XXX Testing irqTimer during syscall
		// asm volatile("int $0x20":::"memory"); //XXX Testing irqTimer during syscall
	}

	updateCursor(displayRow, displayCol);
	// take care of return value
	return;
}

void sysFork(struct StackFrame *sf)
{
	

    int pid = -1;
    int i;
    
    // 1. 寻找一个空闲的PCB作为子进程
    for (i = 1; i < MAX_PCB_NUM; i++) {
        if (pcb[i].state == STATE_DEAD) {
            pid = i;
            break;
        }
    }



    
    // 如果没有找到空闲PCB，fork失败，返回-1
    if (pid == -1) {
        sf->eax = -1;
      
        return;
    }
    

    // 2. 复制父进程的内存空间到子进程
    for (i = 0; i < 0x100000; i++) {
        *(uint8_t *)((pid + 1) * 0x100000 + i) = *(uint8_t *)((current + 1) * 0x100000 + i);
    }


    
    // 3. 设置子进程的PCB
    pcb[pid].pid = pid;
    
    // 计算子进程的栈指针
    // 通过计算父进程的stackTop与其实际地址的偏移量，应用到子进程
    pcb[pid].stackTop = (uint32_t)&(pcb[pid].stackTop) - 
                       ((uint32_t)&(pcb[current].stackTop) - pcb[current].stackTop);
    pcb[pid].prevStackTop = (uint32_t)&(pcb[pid].stackTop) - 
                           ((uint32_t)&(pcb[current].stackTop) - pcb[current].prevStackTop);
    
    // 4. 设置子进程的状态
    pcb[pid].sleepTime = 0;
    pcb[pid].state = STATE_RUNNABLE;
    pcb[pid].timeCount = 0;
    
    // 5. 复制寄存器状态
    pcb[pid].regs.edi = sf->edi;
    pcb[pid].regs.esi = sf->esi;
    pcb[pid].regs.ebp = sf->ebp;
    pcb[pid].regs.xxx = sf->xxx;
    pcb[pid].regs.ebx = sf->ebx;
    pcb[pid].regs.edx = sf->edx;
    pcb[pid].regs.ecx = sf->ecx;
    pcb[pid].regs.eax = sf->eax;
    pcb[pid].regs.irq = sf->irq;
    pcb[pid].regs.error = sf->error;
    pcb[pid].regs.eip = sf->eip;
    pcb[pid].regs.esp = sf->esp;
    pcb[pid].regs.eflags = sf->eflags;
    
    // 6. 设置子进程的段选择子
    // 每个进程有自己的代码段和数据段
    pcb[pid].regs.cs = USEL((1 + pid * 2));
    pcb[pid].regs.ss = USEL((2 + pid * 2));
    pcb[pid].regs.ds = USEL((2 + pid * 2));
    pcb[pid].regs.es = USEL((2 + pid * 2));
    pcb[pid].regs.fs = USEL((2 + pid * 2));
    pcb[pid].regs.gs = USEL((2 + pid * 2));
    
    // 7. 设置返回值
    pcb[pid].regs.eax = 0;    // 子进程返回0
    sf->eax = pid;            // 父进程返回子进程的pid
 
    
    return;
}

void sysExec(struct StackFrame *sf)
{
// TODO: finish exec
	// 获取参数：起始扇区和扇区数
    int first_sector = sf->ecx;
    int sector_count = sf->edx;
    
 


	
	// 加载新程序到当前进程的内存空间
	// loadUMain 返回新程序的入口点地址
	uint32_t entry = loadUMain(first_sector, sector_count, current);
	
	// 初始化进程的执行环境
	// 1. 保持进程ID和状态不变
	// 2. 重置进程的时间片计数
	pcb[current].timeCount = 0;
	// 3. 重置进程的休眠时间
	pcb[current].sleepTime = 0;
	
	// 修改进程的寄存器状态，以便执行新程序
	pcb[current].regs.eip = entry;    // 设置入口点
	pcb[current].regs.esp = 0x200000;  // 固定在用户空间的 2MB 处
	pcb[current].regs.ebp = 0x200000;  // 固定在用户空间的 2MB 处

	
	// 修改段寄存器，保证在正确的地址空间执行
	// 注意：我们保持用户态段选择子不变
	
	// 设置EFLAGS，使能中断
	pcb[current].regs.eflags = 0x202;  // IF位置1，允许中断
	
	// 设置返回值为0表示成功
	sf->eax = 0;
	

	
	// 通过切换上下文来执行新程序
	// 保存当前栈顶
	uint32_t tmpStackTop = pcb[current].stackTop;
	// 更新TSS的esp0
	pcb[current].stackTop = pcb[current].prevStackTop;
	tss.esp0 = pcb[current].stackTop;
	
	// 切换到用户态并开始执行新程序
	asm volatile("movl %0, %%esp" ::"m"(tmpStackTop));
	asm volatile("popl %%gs\n\t"
					"popl %%fs\n\t"
					"popl %%es\n\t"
					"popl %%ds\n\t"
					"popal\n\t"
					"addl $8, %%esp\n\t"  // 跳过irq和error
					"iret"                 // 返回用户态
					::
						: "memory", "cc");
}

void sysSleep(struct StackFrame *sf)
{
// TODO: finish sleep
	// 获取睡眠时间参数
	uint32_t sleepTime = sf->ecx;

	
	// 设置进程的睡眠时间
	pcb[current].sleepTime = sleepTime;
	
	// 将进程状态设置为阻塞
	pcb[current].state = STATE_BLOCKED;
	
	// 设置返回值
	sf->eax = 0;
	
	// 调用schedule()切换到下一个进程
	// schedule()会调用contextSwitch()，完成进程切换并通过iret返回
	schedule();
}

void sysExit(struct StackFrame *sf)
{
	// TODO: finish exit
	// 设置当前进程状态为DEAD
	pcb[current].state = STATE_DEAD;

	
	// 调用schedule()模拟时钟中断触发进程切换
	schedule();
}

void sysGetPid(struct StackFrame *sf)
{
	// TODO: finish getpid
	// Return the pid of the current process in eax register
	sf->eax = current;

		
}